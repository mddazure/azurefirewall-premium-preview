#!/bin/bash

if [[ ! -d /opt/server ]]; then
	# Download the package
	dpkg -i packages/*.deb

	# Configure nginx
	mv server /opt/server
	ln -fs /opt/server/nginx.conf /etc/nginx/nginx.conf
	chown -R root:root /opt/server
	systemctl restart nginx
fi
